<!doctype html>
<html lang="en-US">

<!-- Mirrored from sohom.in/tag/developement/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 12 Apr 2021 07:06:38 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-DHT8X97ENQ"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-DHT8X97ENQ');
</script>
	
	<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'../../../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PL9T2Q4');</script>
<!-- End Google Tag Manager -->
	<meta name="robots" content="index, follow">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="pingback" href="../../xmlrpc.html" />
	
	<!-- This site is optimized with the Yoast SEO plugin v15.9 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>developement Archives - Sohom uPvc Windows &amp; Doors</title>
	<meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1" />
	<link rel="canonical" href="https://sohom.in/development.php" />
	<meta property="og:locale" content="en_US" />
	<meta property="og:type" content="article" />
	<meta property="og:title" content="developement Archives - Sohom uPvc Windows &amp; Doors" />
	<meta property="og:url" content="https://sohom.in/tag/developement/" />
	<meta property="og:site_name" content="Sohom uPvc Windows &amp; Doors" />
	<meta name="twitter:card" content="summary_large_image" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://sohom.in/#website","url":"https://sohom.in/","name":"Sohom uPvc Windows &amp; Doors","description":"Finest Fenestrations","potentialAction":[{"@type":"SearchAction","target":"https://sohom.in/?s={search_term_string}","query-input":"required name=search_term_string"}],"inLanguage":"en-US"},{"@type":"CollectionPage","@id":"https://sohom.in/tag/developement/#webpage","url":"https://sohom.in/tag/developement/","name":"developement Archives - Sohom uPvc Windows &amp; Doors","isPartOf":{"@id":"https://sohom.in/#website"},"breadcrumb":{"@id":"https://sohom.in/tag/developement/#breadcrumb"},"inLanguage":"en-US","potentialAction":[{"@type":"ReadAction","target":["https://sohom.in/tag/developement/"]}]},{"@type":"BreadcrumbList","@id":"https://sohom.in/tag/developement/#breadcrumb","itemListElement":[{"@type":"ListItem","position":1,"item":{"@type":"WebPage","@id":"http://sohom.in/","url":"http://sohom.in/","name":"Home"}},{"@type":"ListItem","position":2,"item":{"@type":"WebPage","@id":"https://sohom.in/tag/developement/","url":"https://sohom.in/tag/developement/","name":"developement"}}]}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='http://translate.google.com/' />
<link rel='dns-prefetch' href='http://fonts.googleapis.com/' />
<link rel='dns-prefetch' href='http://s.w.org/' />
<link rel="alternate" type="application/rss+xml" title="Sohom uPvc Windows &amp; Doors &raquo; Feed" href="../../feed/index.html" />
<link rel="alternate" type="application/rss+xml" title="Sohom uPvc Windows &amp; Doors &raquo; Comments Feed" href="../../comments/feed/index.html" />
<link rel="alternate" type="application/rss+xml" title="Sohom uPvc Windows &amp; Doors &raquo; developement Tag Feed" href="feed/index.html" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/sohom.in\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.5.3"}};
			!function(e,a,t){var r,n,o,i,p=a.createElement("canvas"),s=p.getContext&&p.getContext("2d");function c(e,t){var a=String.fromCharCode;s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,e),0,0);var r=p.toDataURL();return s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,t),0,0),r===p.toDataURL()}function l(e){if(!s||!s.fillText)return!1;switch(s.textBaseline="top",s.font="600 32px Arial",e){case"flag":return!c([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])&&(!c([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!c([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]));case"emoji":return!c([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}function d(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(i=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},o=0;o<i.length;o++)t.supports[i[o]]=l(i[o]),t.supports.everything=t.supports.everything&&t.supports[i[o]],"flag"!==i[o]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[i[o]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(r=t.source||{}).concatemoji?d(r.concatemoji):r.wpemoji&&r.twemoji&&(d(r.twemoji),d(r.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='slickmap.css-css'  href='../../wp-content/plugins/slick-sitemap/slickmap5697.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-css'  href='../../wp-includes/css/dist/block-library/style.min5697.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-theme-css'  href='../../wp-includes/css/dist/block-library/theme.min5697.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='../../wp-content/plugins/contact-form-7/includes/css/stylesde54.css?ver=5.3' type='text/css' media='all' />
<link rel='stylesheet' id='google-language-translator-css'  href='../../wp-content/plugins/google-language-translator/css/styled42d.css?ver=6.0.8' type='text/css' media='' />
<link rel='stylesheet' id='glt-toolbar-styles-css'  href='../../wp-content/plugins/google-language-translator/css/toolbard42d.css?ver=6.0.8' type='text/css' media='' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='../../wp-content/plugins/revslider/public/assets/css/rs6b5e1.css?ver=6.1.5' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='ssb-ui-style-css'  href='../../wp-content/plugins/sticky-side-buttons/assets/css/ssb-ui-style5697.css?ver=5.5.3' type='text/css' media='all' />
<style id='ssb-ui-style-inline-css' type='text/css'>
#ssb-btn-0{background: #00a2e8;}
#ssb-btn-0:hover{background:rgba(0,162,232,0.9);}
#ssb-btn-0 a{color: #ffffff;}
.ssb-share-btn,.ssb-share-btn .ssb-social-popup{background:#00a2e8;color:#ffffff}.ssb-share-btn:hover{background:rgba(0,162,232,0.9);}.ssb-share-btn a{color:#ffffff !important;}#ssb-btn-4{background: #00e676;}
#ssb-btn-4:hover{background:rgba(0,230,118,0.9);}
#ssb-btn-4 a{color: #ffffff;}
#ssb-btn-2{background: #0073b1;}
#ssb-btn-2:hover{background:rgba(0,115,177,0.9);}
#ssb-btn-2 a{color: #ffffff;}
#ssb-btn-1{background: #2d88ff;}
#ssb-btn-1:hover{background:rgba(45,136,255,0.9);}
#ssb-btn-1 a{color: #ffffff;}
#ssb-btn-3{background: #5b51d8;}
#ssb-btn-3:hover{background:rgba(91,81,216,0.9);}
#ssb-btn-3 a{color: #ffffff;}

</style>
<link rel='stylesheet' id='ssb-fontawesome-css'  href='../../wp-content/plugins/sticky-side-buttons/assets/css/font-awesome5697.css?ver=5.5.3' type='text/css' media='all' />
<!--[if lt IE 9]>
<link rel='stylesheet' id='vc_lte_ie9-css'  href='https://sohom.in/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css?ver=6.0.5' type='text/css' media='screen' />
<![endif]-->
<link rel='stylesheet' id='roneous-google-fonts-css'  href='https://fonts.googleapis.com/css?family=Catamaran%3A400%2C100%2C300%2C400%2C600%2C700%7CCatamaran%3A600%2C100%2C300%2C400%2C600%2C700%7CCabin+Condensed%3A700%2C100%2C300%2C400%2C600%2C700%7COpen+Sans%3A300%2C400&amp;subset=latin%2Clatin-ext&amp;ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='roneous-libs-css'  href='../../wp-content/themes/roneous/assets/css/libs5697.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='roneous-theme-styles-css'  href='../../wp-content/uploads/wp-less-cache/roneous-theme-stylesb556.css?ver=1618209933' type='text/css' media='all' />
<link rel='stylesheet' id='roneous-style-css'  href='../../wp-content/themes/roneous/style5697.css?ver=5.5.3' type='text/css' media='all' />
<script type='text/javascript' src='../../wp-includes/js/jquery/jquery4a5f.js?ver=1.12.4-wp' id='jquery-core-js'></script>
<script type='text/javascript' src='../../wp-content/plugins/revslider/public/assets/js/revolution.tools.minf049.js?ver=6.0' id='tp-tools-js'></script>
<script type='text/javascript' src='../../wp-content/plugins/revslider/public/assets/js/rs6.minb5e1.js?ver=6.1.5' id='revmin-js'></script>
<script type='text/javascript' id='ssb-ui-js-js-extra'>
/* <![CDATA[ */
var ssb_ui_data = {"z_index":"99"};
/* ]]> */
</script>
<script type='text/javascript' src='../../wp-content/plugins/sticky-side-buttons/assets/js/ssb-ui-js5697.js?ver=5.5.3' id='ssb-ui-js-js'></script>
<link rel="https://api.w.org/" href="../../wp-json/index.html" /><link rel="alternate" type="application/json" href="../../wp-json/wp/v2/tags/13.json" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="../../xmlrpc0db0.html?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="../../wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.5.3" />
<style type="text/css">p.hello { font-size:12px; color:darkgray; }#google_language_translator, #flags { text-align:left; }#google_language_translator { clear:both; }#flags { width:165px; }#flags a { display:inline-block; margin-right:2px; }#google_language_translator { width:auto !important; }.goog-tooltip {display: none !important;}.goog-tooltip:hover {display: none !important;}.goog-text-highlight {background-color: transparent !important; border: none !important; box-shadow: none !important;}#google_language_translator select.goog-te-combo { color:#32373c; }#google_language_translator {color: transparent;}body { top:0px !important; }#glt-translate-trigger > span { color:#ffffff; }#glt-translate-trigger { background:#f89406; }.goog-te-gadget .goog-te-combo { width:100%; }</style><style type="text/css">
    #mvvwo_floating_button {
        bottom: 20px;
        right: 15px;
        position: fixed;
        z-index: 9999;
		cursor: pointer;
    }

    #mvvwo_floating_button svg {
        fill: #ffffff;
    }

    #mvvwo_floating_button:hover {

    }

    #mvvwo_floating_button .mvvwo_txt {
        display: inline-block;
        vertical-align: bottom;
        line-height: 60px;
        opacity: 0;
        transition: opacity 500ms ease-in;
    }

    #mvvwo_floating_button.mvvwo_show .mvvwo_txt {
        opacity: 1;
    }

    #mvvwo_floating_button .mvvwo_txt a {
        background: #ffffff;
        box-shadow: 0px 0px 5px 0px rgba(136, 136, 136, 0.50);
        padding: 3px 10px;
        border-radius: 5px;
        color: #333333;
        text-decoration: none;
        position: relative;
    }

    #mvvwo_floating_button .mvvwo_txt a:after {
        content: '';
        position: absolute;
        background: #ffffff;

        right: -5px;
        top: 50%;
        margin-top: -4px;
        width: 8px;
        height: 8px;
        z-index: 1;
        -ms-transform: rotate(-45deg);
        -webkit-transform: rotate(-45deg);
        -moz-transform: rotate(-45deg);
        -o-transform: rotate(-45deg);
        transform: rotate(-45deg);
    }

    #mvvwo_floating_button.mvvwo_pos_left .mvvwo_txt a:after {
        left: -4px;
    }

    #mvvwo_floating_button .mvvwo_btn {
        display: inline-block;
        width: 60px;
        height: 60px;
        background: #25D367;
        border-radius: 50%;
        padding: 13px;
        box-shadow: 0px 0px 7px 2px rgba(136, 136, 136, 0.50);
        transform: scale3d(0, 0, 0);
        transition: transform .3s ease-in-out;
        transform-origin: 100% 100%;
        margin: 0 5px;
        box-sizing: border-box;
    }

    #mvvwo_floating_button.mvvwo_pos_left .mvvwo_btn {
        transform-origin: 0% 100%;
    }

    #mvvwo_floating_button.mvvwo_show a.mvvwo_btn {
        transform: scale3d(1, 1, 1);
    }

    #mvvwo_floating_button.mvvwo_pos_left {
        right: auto;
        left: 10px;
    }

    @media (max-width: 480px) {
        #mvvwo_floating_button {
            bottom: 10px;
            right: 10px;
        }
    }

    .mvvwo_cart_page_button {
        margin: 7px 0px;
    }

    .mvvwo_cart_button {
        display: block;
        clear: both;
        padding: 10px 0;
    }

    .mvvwo_cart_button a {
        background: #1ebea5;
        padding: 6px 8px;
        display: inline-block;
        border-radius: 6px;
        color: #ffffff;
        text-decoration: none;
        font-size: 14px;
    }

    .mvvwo_cart_button svg {
        fill: #ffffff;
        width: 25px;
        vertical-align: middle;
        margin-right: 5px;
        display: inline-block;
        margin-top: -5px;
    }

    
    @media (min-width: 1281px) {
    
    }

    .mvvwo_whatsbutton {
        margin: 7px 0px;
    }

    .mvvwo_whatsbutton a {
        background: #1ebea5;
        padding: 6px 8px;
        display: inline-block;
        border-radius: 6px;
        text-decoration: none !important;
        color: #ffffff;
        text-decoration: none;
        font-size: 14px;
    }

    .mvvwo_whatsbutton svg {
        fill: #ffffff;
        width: 25px;
        vertical-align: middle;
        margin-right: 5px;
        display: inline-block;

    }

    @media (min-width: 1281px) {

    
    }
</style>

<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<meta name="generator" content="Powered by Slider Revolution 6.1.5 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="../../wp-content/uploads/2020/07/cropped-image2-1-32x32.png" sizes="32x32" />
<link rel="icon" href="../../wp-content/uploads/2020/07/cropped-image2-1-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="../../wp-content/uploads/2020/07/cropped-image2-1-180x180.png" />
<meta name="msapplication-TileImage" content="https://sohom.in/wp-content/uploads/2020/07/cropped-image2-1-270x270.png" />
<script type="text/javascript">function setREVStartSize(t){try{var h,e=document.getElementById(t.c).parentNode.offsetWidth;if(e=0===e||isNaN(e)?window.innerWidth:e,t.tabw=void 0===t.tabw?0:parseInt(t.tabw),t.thumbw=void 0===t.thumbw?0:parseInt(t.thumbw),t.tabh=void 0===t.tabh?0:parseInt(t.tabh),t.thumbh=void 0===t.thumbh?0:parseInt(t.thumbh),t.tabhide=void 0===t.tabhide?0:parseInt(t.tabhide),t.thumbhide=void 0===t.thumbhide?0:parseInt(t.thumbhide),t.mh=void 0===t.mh||""==t.mh||"auto"===t.mh?0:parseInt(t.mh,0),"fullscreen"===t.layout||"fullscreen"===t.l)h=Math.max(t.mh,window.innerHeight);else{for(var i in t.gw=Array.isArray(t.gw)?t.gw:[t.gw],t.rl)void 0!==t.gw[i]&&0!==t.gw[i]||(t.gw[i]=t.gw[i-1]);for(var i in t.gh=void 0===t.el||""===t.el||Array.isArray(t.el)&&0==t.el.length?t.gh:t.el,t.gh=Array.isArray(t.gh)?t.gh:[t.gh],t.rl)void 0!==t.gh[i]&&0!==t.gh[i]||(t.gh[i]=t.gh[i-1]);var r,a=new Array(t.rl.length),n=0;for(var i in t.tabw=t.tabhide>=e?0:t.tabw,t.thumbw=t.thumbhide>=e?0:t.thumbw,t.tabh=t.tabhide>=e?0:t.tabh,t.thumbh=t.thumbhide>=e?0:t.thumbh,t.rl)a[i]=t.rl[i]<window.innerWidth?0:t.rl[i];for(var i in r=a[0],a)r>a[i]&&0<a[i]&&(r=a[i],n=i);var d=e>t.gw[n]+t.tabw+t.thumbw?1:(e-(t.tabw+t.thumbw))/t.gw[n];h=t.gh[n]*d+(t.tabh+t.thumbh)}void 0===window.rs_init_css&&(window.rs_init_css=document.head.appendChild(document.createElement("style"))),document.getElementById(t.c).height=h,window.rs_init_css.innerHTML+="#"+t.c+"_wrapper { height: "+h+"px }"}catch(t){console.log("Failure at Presize of Slider:"+t)}};</script>
		<style type="text/css" id="wp-custom-css">
			.heading-title {
    font-size: 50px;
    letter-spacing: -0.02em;
}
.textwidget a {
	color: white !important;
	font-style: normal;
	font-family: Josefin Sans, arial, sans-serif;
}

.widget{
	margin-bottom: 30px;
}
#media_image-4{
	display: inline-block;
	margin-right: 40px;
}
#media_image-5{
	display: inline-block;
}

		</style>
		<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>
<body class="archive tag tag-developement tag-13 normal-layout wpb-js-composer js-comp-ver-6.0.5 vc_responsive">
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PL9T2Q4"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

			<div class="nav-container">
    <nav class="transparent absolute">
        <div class="nav-bar">
            <div class="module left">
                <a href="../../index.html">
                                        <img class="logo logo-light" alt="Sohom uPvc Windows &amp; Doors" src="../../wp-content/uploads/2020/07/image3-1.png" />
                    <img class="logo logo-dark" alt="Sohom uPvc Windows &amp; Doors" src="../../wp-content/uploads/2020/07/image3-1.png" />
                                    </a>
            </div>
            <div class="module widget-wrap mobile-toggle right visible-sm visible-xs">
                <i class="ti-menu"></i>
            </div>
            <div class="module-group right">
                <div class="module left">
                    <ul id="menu-main-menu" class="menu"><li id="menu-item-237"  class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-237"><a href="../../index.html">Home</a><li id="menu-item-412"  class="menu-item menu-item-type-post_type menu-item-object-page menu-item-412"><a href="../../about/index.html">About</a><li id="menu-item-413"  class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-413 has-dropdown"><a href="#">Products</a>
<ul role="menu" class=" subnav">
	<li id="menu-item-414"  class="menu-item menu-item-type-post_type menu-item-object-page menu-item-414"><a href="../../lift-slide-system/index.html">Lift &#038; Slide System</a>	<li id="menu-item-415"  class="menu-item menu-item-type-post_type menu-item-object-page menu-item-415"><a href="../../bi-fold-system/index.html">Bi-Fold System</a>	<li id="menu-item-416"  class="menu-item menu-item-type-post_type menu-item-object-page menu-item-416"><a href="../../casement-doors-windows/index.html">Casement Doors &#038; Windows</a>	<li id="menu-item-417"  class="menu-item menu-item-type-post_type menu-item-object-page menu-item-417"><a href="../../sliding-doors-windows/index.html">Sliding Doors &#038; Windows</a></ul>
<li id="menu-item-687"  class="menu-item menu-item-type-post_type menu-item-object-page menu-item-687"><a href="../../testimonials/index.html">Testimonials</a><li id="menu-item-688"  class="menu-item menu-item-type-post_type menu-item-object-page menu-item-688"><a href="../../case-studies/index.html">Case Studies</a><li id="menu-item-689"  class="menu-item menu-item-type-post_type menu-item-object-page menu-item-689"><a href="../../events/index.html">Events</a><li id="menu-item-697"  class="menu-item menu-item-type-post_type menu-item-object-page menu-item-697"><a href="../../contact/index.html">Contact</a><li id="menu-item-1268"  class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1268 megamenu-item"><a href="../../sitemap/index.html">Sitemap</a></ul>                </div>
				            </div>
        </div>
    </nav>
</div>	<div class="main-container"><section class="page-title page-title-center ">
							<div class="container"><div class="row"><div class="col-sm-12 text-center">
					        	<h1 class="heading-title mb0">Tag: developement</h1>
					        	<p class="lead fade-color mb0"></p>
							</div></div></div><ol class="breadcrumb breadcrumb-style"><li><a href="../../index.html" class="home-link" rel="home">Home</a></li><li class="active">Our Blog</li></ol></section><section class="p0">
    <div class="container">
        <div class="row">
            <div id="main-content" class="col-md-9 mb-xs-24">
            	<div class="post-wrap mb64 ">
	<div class="inner-wrap border-none p0">
		<div class="inner-left">
			<div class="day">03</div>
			<div class="month">Aug</div>
		</div>
		<div class="inner-right">
		    <div class="post-title">
    <h4><a class="link-dark-title entry-title" href="../../2016/08/03/guests-are-satisfied-with-our-services-c/index.html">Guests are satisfied with our services</a></h4></div>
<div class="entry-meta mt8 mb16 p0">
	<span class="inline-block hide updated"><i class="ti-timer"></i>August 3, 2016</span>
	<span class="inline-block author"><i class="ti-user"></i><span>by</span><a href="../../author/hw_sohom08/index.html" title="Posts by HW_Sohom@08" rel="author">HW_Sohom@08</a></span>
			<span class="inline-block"><i class="ti-folder"></i><span>in</span><a href="../../category/design/index.html" rel="category tag">Design</a>,</span><span class="inline-block"><a href="../../category/psd/index.html" rel="category tag">PSD</a></span>
		</div><a href="../../2016/08/03/guests-are-satisfied-with-our-services-c/index.html">
<img width="717" height="297" src="../../wp-content/uploads/2016/08/cover-11.jpg" class="mb16 wp-post-image" alt="" loading="lazy" srcset="https://sohom.in/wp-content/uploads/2016/08/cover-11.jpg 717w, https://sohom.in/wp-content/uploads/2016/08/cover-11-600x249.jpg 600w, https://sohom.in/wp-content/uploads/2016/08/cover-11-300x124.jpg 300w" sizes="(max-width: 717px) 100vw, 717px" /></a>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed lacinia dapibus est vitae lobortis. Ut congue&#8230;</p>
			<div class="overflow-hidden">
				<div class="pull-left">
					<span class="read-more"><a href="../../2016/08/03/guests-are-satisfied-with-our-services-c/index.html"><span data-hover="Read More">Read More</span></a></span>
				</div>
				<div class="pull-right">
						        <div class="tlg-likes-button inline-block tlg-likes-normal">
	        	<a href="#" class="tlg-likes" id="tlg-likes-30" title="">
	        		<i class="ti-heart"></i><span class="like-share-name">0<span> like</span></span>	        	</a>
	        </div>
	        				</div>
			</div>
		</div>
	</div>
</div>            </div>
            <div id="sidebar" class="col-md-3 hidden-sm-xs bg-secondary">
	</div>        </div>
    </div>
</section>		<footer class="footer-widget bg-graydark  ">
    <div class="large-container">
        <div class="row">
        	<div class="col-sm-6"><div id="text-3" class="widget widget_text"><h6 class="title">Contact Information</h6>			<div class="textwidget"><p>Address: 12-5-110, Moosapet, Bombay Road, Near Metro Pillar A910, Hyderabad 500018.</p>
<p>Mobile: +91 8886600605 | 8886600616.</p>
<p>Email: sales@sohom.in</p>
</div>
		</div><div id="custom_html-4" class="widget_text widget widget_custom_html"><h6 class="title">Follow Us On Social Media</h6><div class="textwidget custom-html-widget"><a href="https://www.linkedin.com/company/47595200" style="margin-right: 30px"><span><i class="fa fa-linkedin"></i></span></a>
<a href="https://www.facebook.com/sohomindia/" style="margin-right: 30px"><span><i class="fa fa-facebook"></i></span></a>
<a href="https://www.instagram.com/sohomindia/"><span><i class="fa fa-instagram"></i></span></a></div></div><div id="text-9" class="widget widget_text">			<div class="textwidget"><p><a href="../../disclaimer/index.html">Disclaimer</a> | <a href="../../privacy-policy-2/index.html">Privacy Policy</a> | <a href="../../sitemap/index.html">Sitemap</a></p>
</div>
		</div></div><div class="col-sm-6"><div id="text-6" class="widget widget_text">			<div class="textwidget"><p><iframe style="border: 0;" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d7611.703640277792!2d78.42892!3d17.466805!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x6b70cc0eefbb0808!2sSohom+Fenstertech+Pvt+Ltd.!5e0!3m2!1sen!2sin!4v1544596547574" width="100%" height="220px" frameborder="0" allowfullscreen="allowfullscreen"></iframe></p>
</div>
		</div><div id="media_image-4" class="widget widget_media_image"><a href="https://www.uwdmaindia.org/"><img width="60" height="60" src="../../wp-content/uploads/2020/07/image4-1-60x60.png" class="image wp-image-733  attachment-60x60 size-60x60" alt="" loading="lazy" style="max-width: 100%; height: auto;" srcset="https://sohom.in/wp-content/uploads/2020/07/image4-1-60x60.png 60w, https://sohom.in/wp-content/uploads/2020/07/image4-1.png 100w" sizes="(max-width: 60px) 100vw, 60px" /></a></div><div id="media_image-5" class="widget widget_media_image"><a href="https://deceuninck.in/"><img width="60" height="60" src="../../wp-content/uploads/2020/07/image7-1-60x60.png" class="image wp-image-737  attachment-60x60 size-60x60" alt="" loading="lazy" style="max-width: 100%; height: auto;" srcset="https://sohom.in/wp-content/uploads/2020/07/image7-1-60x60.png 60w, https://sohom.in/wp-content/uploads/2020/07/image7-1.png 100w" sizes="(max-width: 60px) 100vw, 60px" /></a></div></div><div class="clear"></div>        </div>
    </div>
        <div class="large-container sub-footer">
        <div class="row">
            <div class="col-sm-6">
                <span class="sub">
                    Copyright © 2012 SOHOM. All rights reserved.                </span>
            </div>
            <div class="col-sm-6 text-right">
                <ul class="list-inline social-list">
                                    </ul>
            </div>
        </div>
    </div>
    </footer>					<div class="back-to-top"><i class="ti-angle-up"></i></div>
			</div><!--END: main-container-->
	<div id="glt-translate-trigger"><span class="translate">Translate »</span></div><div id="glt-toolbar"></div><div id="flags" style="display:none" class="size18"><ul id="sortable" class="ui-sortable"><li id="Afrikaans"><a href="#" title="Afrikaans" class="nturl notranslate af flag Afrikaans"></a></li><li id="Albanian"><a href="#" title="Albanian" class="nturl notranslate sq flag Albanian"></a></li><li id="Amharic"><a href="#" title="Amharic" class="nturl notranslate am flag Amharic"></a></li><li id="Arabic"><a href="#" title="Arabic" class="nturl notranslate ar flag Arabic"></a></li><li id="Armenian"><a href="#" title="Armenian" class="nturl notranslate hy flag Armenian"></a></li><li id="Azerbaijani"><a href="#" title="Azerbaijani" class="nturl notranslate az flag Azerbaijani"></a></li><li id="Basque"><a href="#" title="Basque" class="nturl notranslate eu flag Basque"></a></li><li id="Belarusian"><a href="#" title="Belarusian" class="nturl notranslate be flag Belarusian"></a></li><li id="Bengali"><a href="#" title="Bengali" class="nturl notranslate bn flag Bengali"></a></li><li id="Bosnian"><a href="#" title="Bosnian" class="nturl notranslate bs flag Bosnian"></a></li><li id="Bulgarian"><a href="#" title="Bulgarian" class="nturl notranslate bg flag Bulgarian"></a></li><li id="Catalan"><a href="#" title="Catalan" class="nturl notranslate ca flag Catalan"></a></li><li id="Cebuano"><a href="#" title="Cebuano" class="nturl notranslate ceb flag Cebuano"></a></li><li id="Chichewa"><a href="#" title="Chichewa" class="nturl notranslate ny flag Chichewa"></a></li><li id="Chinese (Simplified)"><a href="#" title="Chinese (Simplified)" class="nturl notranslate zh-CN flag Chinese (Simplified)"></a></li><li id="Chinese (Traditional)"><a href="#" title="Chinese (Traditional)" class="nturl notranslate zh-TW flag Chinese (Traditional)"></a></li><li id="Corsican"><a href="#" title="Corsican" class="nturl notranslate co flag Corsican"></a></li><li id="Croatian"><a href="#" title="Croatian" class="nturl notranslate hr flag Croatian"></a></li><li id="Czech"><a href="#" title="Czech" class="nturl notranslate cs flag Czech"></a></li><li id="Danish"><a href="#" title="Danish" class="nturl notranslate da flag Danish"></a></li><li id="Dutch"><a href="#" title="Dutch" class="nturl notranslate nl flag Dutch"></a></li><li id="English"><a href="#" title="English" class="nturl notranslate en flag united-states"></a></li><li id="Esperanto"><a href="#" title="Esperanto" class="nturl notranslate eo flag Esperanto"></a></li><li id="Estonian"><a href="#" title="Estonian" class="nturl notranslate et flag Estonian"></a></li><li id="Filipino"><a href="#" title="Filipino" class="nturl notranslate tl flag Filipino"></a></li><li id="Finnish"><a href="#" title="Finnish" class="nturl notranslate fi flag Finnish"></a></li><li id="French"><a href="#" title="French" class="nturl notranslate fr flag French"></a></li><li id="Frisian"><a href="#" title="Frisian" class="nturl notranslate fy flag Frisian"></a></li><li id="Galician"><a href="#" title="Galician" class="nturl notranslate gl flag Galician"></a></li><li id="Georgian"><a href="#" title="Georgian" class="nturl notranslate ka flag Georgian"></a></li><li id="German"><a href="#" title="German" class="nturl notranslate de flag German"></a></li><li id="Greek"><a href="#" title="Greek" class="nturl notranslate el flag Greek"></a></li><li id="Gujarati"><a href="#" title="Gujarati" class="nturl notranslate gu flag Gujarati"></a></li><li id="Haitian"><a href="#" title="Haitian" class="nturl notranslate ht flag Haitian"></a></li><li id="Hausa"><a href="#" title="Hausa" class="nturl notranslate ha flag Hausa"></a></li><li id="Hawaiian"><a href="#" title="Hawaiian" class="nturl notranslate haw flag Hawaiian"></a></li><li id="Hebrew"><a href="#" title="Hebrew" class="nturl notranslate iw flag Hebrew"></a></li><li id="Hindi"><a href="#" title="Hindi" class="nturl notranslate hi flag Hindi"></a></li><li id="Hmong"><a href="#" title="Hmong" class="nturl notranslate hmn flag Hmong"></a></li><li id="Hungarian"><a href="#" title="Hungarian" class="nturl notranslate hu flag Hungarian"></a></li><li id="Icelandic"><a href="#" title="Icelandic" class="nturl notranslate is flag Icelandic"></a></li><li id="Igbo"><a href="#" title="Igbo" class="nturl notranslate ig flag Igbo"></a></li><li id="Indonesian"><a href="#" title="Indonesian" class="nturl notranslate id flag Indonesian"></a></li><li id="Irish"><a href="#" title="Irish" class="nturl notranslate ga flag Irish"></a></li><li id="Italian"><a href="#" title="Italian" class="nturl notranslate it flag Italian"></a></li><li id="Japanese"><a href="#" title="Japanese" class="nturl notranslate ja flag Japanese"></a></li><li id="Javanese"><a href="#" title="Javanese" class="nturl notranslate jw flag Javanese"></a></li><li id="Kannada"><a href="#" title="Kannada" class="nturl notranslate kn flag Kannada"></a></li><li id="Kazakh"><a href="#" title="Kazakh" class="nturl notranslate kk flag Kazakh"></a></li><li id="Khmer"><a href="#" title="Khmer" class="nturl notranslate km flag Khmer"></a></li><li id="Korean"><a href="#" title="Korean" class="nturl notranslate ko flag Korean"></a></li><li id="Kurdish"><a href="#" title="Kurdish" class="nturl notranslate ku flag Kurdish"></a></li><li id="Kyrgyz"><a href="#" title="Kyrgyz" class="nturl notranslate ky flag Kyrgyz"></a></li><li id="Lao"><a href="#" title="Lao" class="nturl notranslate lo flag Lao"></a></li><li id="Latin"><a href="#" title="Latin" class="nturl notranslate la flag Latin"></a></li><li id="Latvian"><a href="#" title="Latvian" class="nturl notranslate lv flag Latvian"></a></li><li id="Lithuanian"><a href="#" title="Lithuanian" class="nturl notranslate lt flag Lithuanian"></a></li><li id="Luxembourgish"><a href="#" title="Luxembourgish" class="nturl notranslate lb flag Luxembourgish"></a></li><li id="Macedonian"><a href="#" title="Macedonian" class="nturl notranslate mk flag Macedonian"></a></li><li id="Malagasy"><a href="#" title="Malagasy" class="nturl notranslate mg flag Malagasy"></a></li><li id="Malayalam"><a href="#" title="Malayalam" class="nturl notranslate ml flag Malayalam"></a></li><li id="Malay"><a href="#" title="Malay" class="nturl notranslate ms flag Malay"></a></li><li id="Maltese"><a href="#" title="Maltese" class="nturl notranslate mt flag Maltese"></a></li><li id="Maori"><a href="#" title="Maori" class="nturl notranslate mi flag Maori"></a></li><li id="Marathi"><a href="#" title="Marathi" class="nturl notranslate mr flag Marathi"></a></li><li id="Mongolian"><a href="#" title="Mongolian" class="nturl notranslate mn flag Mongolian"></a></li><li id="Myanmar (Burmese)"><a href="#" title="Myanmar (Burmese)" class="nturl notranslate my flag Myanmar (Burmese)"></a></li><li id="Nepali"><a href="#" title="Nepali" class="nturl notranslate ne flag Nepali"></a></li><li id="Norwegian"><a href="#" title="Norwegian" class="nturl notranslate no flag Norwegian"></a></li><li id="Pashto"><a href="#" title="Pashto" class="nturl notranslate ps flag Pashto"></a></li><li id="Persian"><a href="#" title="Persian" class="nturl notranslate fa flag Persian"></a></li><li id="Polish"><a href="#" title="Polish" class="nturl notranslate pl flag Polish"></a></li><li id="Portuguese"><a href="#" title="Portuguese" class="nturl notranslate pt flag Portuguese"></a></li><li id="Punjabi"><a href="#" title="Punjabi" class="nturl notranslate pa flag Punjabi"></a></li><li id="Romanian"><a href="#" title="Romanian" class="nturl notranslate ro flag Romanian"></a></li><li id="Russian"><a href="#" title="Russian" class="nturl notranslate ru flag Russian"></a></li><li id="Serbian"><a href="#" title="Serbian" class="nturl notranslate sr flag Serbian"></a></li><li id="Shona"><a href="#" title="Shona" class="nturl notranslate sn flag Shona"></a></li><li id="Sesotho"><a href="#" title="Sesotho" class="nturl notranslate st flag Sesotho"></a></li><li id="Sindhi"><a href="#" title="Sindhi" class="nturl notranslate sd flag Sindhi"></a></li><li id="Sinhala"><a href="#" title="Sinhala" class="nturl notranslate si flag Sinhala"></a></li><li id="Slovak"><a href="#" title="Slovak" class="nturl notranslate sk flag Slovak"></a></li><li id="Slovenian"><a href="#" title="Slovenian" class="nturl notranslate sl flag Slovenian"></a></li><li id="Samoan"><a href="#" title="Samoan" class="nturl notranslate sm flag Samoan"></a></li><li id="Scots Gaelic"><a href="#" title="Scots Gaelic" class="nturl notranslate gd flag Scots Gaelic"></a></li><li id="Somali"><a href="#" title="Somali" class="nturl notranslate so flag Somali"></a></li><li id="Spanish"><a href="#" title="Spanish" class="nturl notranslate es flag Spanish"></a></li><li id="Sundanese"><a href="#" title="Sundanese" class="nturl notranslate su flag Sundanese"></a></li><li id="Swahili"><a href="#" title="Swahili" class="nturl notranslate sw flag Swahili"></a></li><li id="Swedish"><a href="#" title="Swedish" class="nturl notranslate sv flag Swedish"></a></li><li id="Tajik"><a href="#" title="Tajik" class="nturl notranslate tg flag Tajik"></a></li><li id="Tamil"><a href="#" title="Tamil" class="nturl notranslate ta flag Tamil"></a></li><li id="Telugu"><a href="#" title="Telugu" class="nturl notranslate te flag Telugu"></a></li><li id="Thai"><a href="#" title="Thai" class="nturl notranslate th flag Thai"></a></li><li id="Turkish"><a href="#" title="Turkish" class="nturl notranslate tr flag Turkish"></a></li><li id="Ukrainian"><a href="#" title="Ukrainian" class="nturl notranslate uk flag Ukrainian"></a></li><li id="Urdu"><a href="#" title="Urdu" class="nturl notranslate ur flag Urdu"></a></li><li id="Uzbek"><a href="#" title="Uzbek" class="nturl notranslate uz flag Uzbek"></a></li><li id="Vietnamese"><a href="#" title="Vietnamese" class="nturl notranslate vi flag Vietnamese"></a></li><li id="Welsh"><a href="#" title="Welsh" class="nturl notranslate cy flag Welsh"></a></li><li id="Xhosa"><a href="#" title="Xhosa" class="nturl notranslate xh flag Xhosa"></a></li><li id="Yiddish"><a href="#" title="Yiddish" class="nturl notranslate yi flag Yiddish"></a></li><li id="Yoruba"><a href="#" title="Yoruba" class="nturl notranslate yo flag Yoruba"></a></li><li id="Zulu"><a href="#" title="Zulu" class="nturl notranslate zu flag Zulu"></a></li></ul></div><div id='glt-footer'><div id="google_language_translator" class="default-language-en"></div></div><script>function GoogleLanguageTranslatorInit() { new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages:'af,sq,am,ar,hy,az,eu,be,bn,bs,bg,ca,ceb,ny,zh-CN,zh-TW,co,hr,cs,da,nl,en,eo,et,tl,fi,fr,fy,gl,ka,de,el,gu,ht,ha,haw,iw,hi,hmn,hu,is,ig,id,ga,it,ja,jw,kn,kk,km,ko,ku,ky,lo,la,lv,lt,lb,mk,mg,ml,ms,mt,mi,mr,mn,my,ne,no,ps,fa,pl,pt,pa,ro,ru,sr,sn,st,sd,si,sk,sl,sm,gd,so,es,su,sw,sv,tg,ta,te,th,tr,uk,ur,uz,vi,cy,xh,yi,yo,zu', autoDisplay: false}, 'google_language_translator');}</script><div id="mvvwo_floating_button" class="mvvwo_pos_left">
        <a target="_blank"
       data-message="Hello, I'm looking for"
       class="mvvwo_btn" href="#">
        <svg enable-background="new 0 0 90 90" version="1.1" viewBox="0 0 90 90" xml:space="preserve"
             xmlns="http://www.w3.org/2000/svg">
	<path d="m90 43.841c0 24.213-19.779 43.841-44.182 43.841-7.747 0-15.025-1.98-21.357-5.455l-24.461 7.773 7.975-23.522c-4.023-6.606-6.34-14.354-6.34-22.637 0-24.213 19.781-43.841 44.183-43.841 24.405 0 44.182 19.628 44.182 43.841zm-44.182-36.859c-20.484 0-37.146 16.535-37.146 36.859 0 8.065 2.629 15.534 7.076 21.61l-4.641 13.689 14.275-4.537c5.865 3.851 12.891 6.097 20.437 6.097 20.481 0 37.146-16.533 37.146-36.857s-16.664-36.861-37.147-36.861zm22.311 46.956c-0.273-0.447-0.994-0.717-2.076-1.254-1.084-0.537-6.41-3.138-7.4-3.495-0.993-0.358-1.717-0.538-2.438 0.537-0.721 1.076-2.797 3.495-3.43 4.212-0.632 0.719-1.263 0.809-2.347 0.271-1.082-0.537-4.571-1.673-8.708-5.333-3.219-2.848-5.393-6.364-6.025-7.441-0.631-1.075-0.066-1.656 0.475-2.191 0.488-0.482 1.084-1.255 1.625-1.882 0.543-0.628 0.723-1.075 1.082-1.793 0.363-0.717 0.182-1.344-0.09-1.883-0.27-0.537-2.438-5.825-3.34-7.977-0.902-2.15-1.803-1.792-2.436-1.792-0.631 0-1.354-0.09-2.076-0.09s-1.896 0.269-2.889 1.344c-0.992 1.076-3.789 3.676-3.789 8.963 0 5.288 3.879 10.397 4.422 11.113 0.541 0.716 7.49 11.92 18.5 16.223 11.011 4.301 11.011 2.866 12.997 2.686 1.984-0.179 6.406-2.599 7.312-5.107 0.9-2.512 0.9-4.663 0.631-5.111z"/>
</svg>
    </a>
    <div  class="mvvwo_txt"><a target="_blank" 
        data-message="Hello, I'm looking for"  href="#">Click for Enquiry!</a></div></div>

                <div id="ssb-container"
                     class="ssb-btns-right ssb-anim-slide">
                    <ul class="ssb-dark-hover">
						                            <li id="ssb-btn-0">
                                <p>
                                    <a href="../../contact/index.html" ><span class="fas fa-question"></span> Enquiry, Now!</a>
                                </p>
                            </li>
							                            <li id="ssb-btn-4">
                                <p>
                                    <a href="https://api.whatsapp.com/send?phone=918108881642" ><span class="fab fa-whatsapp"></span> Contact Us</a>
                                </p>
                            </li>
							                            <li id="ssb-btn-2">
                                <p>
                                    <a href="https://www.linkedin.com/company/47595200" ><span class="fab fa-linkedin"></span> Follow Us</a>
                                </p>
                            </li>
							                            <li id="ssb-btn-1">
                                <p>
                                    <a href="https://www.facebook.com/sohomindia/" ><span class="fab fa-facebook"></span> Follow Us</a>
                                </p>
                            </li>
							                            <li id="ssb-btn-3">
                                <p>
                                    <a href="https://www.instagram.com/sohomindia/" ><span class="fab fa-instagram"></span> Follow Us</a>
                                </p>
                            </li>
							                    </ul>
                </div>
				<script>
    var mvv_whatsAppLink = function (mobile, message) {
        mobile = mobile.replace(/[^0-9]/g, '');
        return 'https://api.whatsapp.com/send?phone=' + mobile + '&text=' + encodeURI(message);
    }

    var mvvwo_replace = function (txt, ele) {
        if (ele.getAttribute('data-replacesUpdated')) {
            var replaces = JSON.parse(ele.getAttribute('data-replacesUpdated'));
        } else {
            var replaces = JSON.parse(ele.getAttribute('data-replaces'));
        }
        if (replaces) {
            Object.keys(replaces).forEach(function (e) {
                var re = new RegExp(e, 'g')
                txt = txt.replace(re, replaces[e]);

            })
        }

        txt = txt.replace(/{PAGE_URL}/, window.location.href);

        return txt;
    }

    function mvvwo_init() {

        var mvvwo_ele = document.getElementById('mvvwo_floating_button');
        var mvvwo_numbers=[{"avatar":"https:\/\/sohom.in\/wp-content\/plugins\/order-on-chat-for-woocommerce\/includes\/..\/assets\/profile.png","number":"+91 8886600604","name":"Sohom","active":true,"availDays":false,"availTime":false}];        var mvvwoIsOnline = true;
        var mvvwo_numbersAvailable = mvvwo_numbers.filter(function (e) {
            if (e.availDays == false && e.availTime == false) {
                return true;
            }
            var day = new Date().getDay();
            if (e.availDays != false && e.availDays.indexOf(day) < 0) {
                return false;
            }
            var mnts = new Date().getHours() * 60 + new Date().getMinutes() * 1;
            if (e.availTime != false && (mnts > e.availTime[1] || mnts < e.availTime[0])) {
                return false;
            }
            return true;

        })
        if (mvvwo_numbersAvailable.length == 0) {
            mvvwo_numbersAvailable = mvvwo_numbers[0];
            mvvwoIsOnline = false;

        } else {
            mvvwo_numbersAvailable = mvvwo_numbersAvailable[Math.floor(Math.random() * mvvwo_numbersAvailable.length)];
            /* select an number randomly*/
        }
                if (mvvwo_ele) {
            mvvwo_ele.querySelectorAll('a').forEach(function (link) {
                var mvv_message = link.getAttribute('data-message');
                mvv_message = mvv_message.replace(/{PAGE_URL}/, window.location.href);
                link.setAttribute('href', mvv_whatsAppLink(mvvwo_numbersAvailable.number, mvv_message));

            });
        }
                document.querySelectorAll('.mvvwo_whatsbutton a').forEach(function (link) {
            var mvv_message = link.getAttribute('data-message');
            mvv_message = mvv_message.replace(/{PAGE_URL}/, window.location.href);
            link.setAttribute('href', mvv_whatsAppLink(mvvwo_numbersAvailable.number, mvv_message));
        })
        document.querySelectorAll('.mvvwo_cart_page_button a').forEach(function (link) {
            var mvv_message = link.getAttribute('data-message');
            link.setAttribute('href', mvv_whatsAppLink(mvvwo_numbersAvailable.number, mvv_message));
        })


        if (mvvwo_ele) {
            setTimeout(function () {
                mvvwo_ele.className = mvvwo_ele.className + ' mvvwo_show';
            }, 2000)
        }

    }

    if (window.jQuery) {
        jQuery(document).ready(function ($) {
            $(document).on('reset_data', ".variations_form", function (event, variation) {
                $(".mvvwo_cart_button a", $(event.currentTarget)).data("replacesUpdated", false);
            })
            $(document).on('show_variation', ".variations_form", function (event, variation) {

                var varName = [];
                if (variation.attributes) {
                    var varName = Object.keys(variation.attributes).filter(function (e) {
                        return variation.attributes[e] != null && variation.attributes[e] != ''
                    }).map(function (e) {
                        return $("select[name=" + e + "] option[value=" + variation.attributes[e] + "]", $(event.currentTarget)).text();
                    })

                }
                var replaces = $(".mvvwo_cart_button a", $(event.currentTarget)).data("replaces");
                var replacesUpdated = Object.assign({}, replaces);
                replacesUpdated['{PRODUCT_NAME}'] = replaces['{PRODUCT_NAME}'] + ' ' + varName.join(',')
                if (variation.display_price) {
                    replacesUpdated['{PRODUCT_PRICE}'] = replaces['{PRODUCT_PRICE}'].replace(/([0-9,.]+)/, variation.display_price)
                }
                $(".mvvwo_cart_button a", $(event.currentTarget)).attr("data-replacesUpdated", JSON.stringify(replacesUpdated));
            })
        });
    }
    mvvwo_init();
</script>


<script type='text/javascript' id='contact-form-7-js-extra'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/sohom.in\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type='text/javascript' src='../../wp-content/plugins/contact-form-7/includes/js/scriptsde54.js?ver=5.3' id='contact-form-7-js'></script>
<script type='text/javascript' src='../../wp-content/plugins/google-language-translator/js/scriptsd42d.js?ver=6.0.8' id='scripts-js'></script>
<script type='text/javascript' src='../../../translate.google.com/translate_a/elementcd15.html?cb=GoogleLanguageTranslatorInit' id='scripts-google-js'></script>
<script type='text/javascript' src='../../wp-includes/js/jquery/ui/core.mine899.js?ver=1.11.4' id='jquery-ui-core-js'></script>
<script type='text/javascript' src='../../wp-includes/js/jquery/ui/effect.mine899.js?ver=1.11.4' id='jquery-effects-core-js'></script>
<script type='text/javascript' src='../../wp-includes/js/jquery/ui/effect-shake.mine899.js?ver=1.11.4' id='jquery-effects-shake-js'></script>
<script type='text/javascript' src='../../wp-content/themes/roneous/assets/js/bootstrap5697.js?ver=5.5.3' id='bootstrap-js'></script>
<script type='text/javascript' src='../../wp-includes/js/imagesloaded.mineda1.js?ver=4.1.4' id='imagesloaded-js'></script>
<script type='text/javascript' src='../../wp-includes/js/masonry.min3a05.js?ver=4.2.2' id='masonry-js'></script>
<script type='text/javascript' src='../../wp-content/themes/roneous/assets/js/lib/jquery.equalheights.min5697.js?ver=5.5.3' id='equalheights-js'></script>
<script type='text/javascript' src='../../wp-content/themes/roneous/assets/js/lib/jquery.smooth-scroll.min5697.js?ver=5.5.3' id='smoothscroll-js'></script>
<script type='text/javascript' src='../../wp-content/themes/roneous/assets/js/lib/owl.carousel.min5697.js?ver=5.5.3' id='owlcarousel-js'></script>
<script type='text/javascript' src='../../wp-content/plugins/js_composer/assets/lib/bower/flexslider/jquery.flexslider-min52c7.js?ver=6.0.5' id='flexslider-js'></script>
<script type='text/javascript' src='../../wp-content/themes/roneous/assets/js/lib/jquery.social-share-counter5697.js?ver=5.5.3' id='social-share-counter-js'></script>
<script type='text/javascript' src='../../wp-content/themes/roneous/assets/js/lib/flickrPhotoStream5697.js?ver=5.5.3' id='flickr-photo-stream-js'></script>
<script type='text/javascript' src='../../wp-content/themes/roneous/assets/js/lib/jquery.parallax5697.js?ver=5.5.3' id='jsparallax-js'></script>
<script type='text/javascript' src='../../wp-content/themes/roneous/assets/js/lib/waypoint5697.js?ver=5.5.3' id='waypoint-js'></script>
<script type='text/javascript' src='../../wp-content/themes/roneous/assets/js/lib/jquery.counterup5697.js?ver=5.5.3' id='counterup-js'></script>
<script type='text/javascript' src='../../wp-content/themes/roneous/assets/js/lib/lightbox.min5697.js?ver=5.5.3' id='jslightbox-js'></script>
<script type='text/javascript' src='../../wp-content/themes/roneous/assets/js/lib/jquery.mb.YTPlayer.min5697.js?ver=5.5.3' id='mb-ytplayer-js'></script>
<script type='text/javascript' src='../../wp-content/themes/roneous/assets/js/lib/jquery.countdown.min5697.js?ver=5.5.3' id='countdown-js'></script>
<script type='text/javascript' src='../../wp-content/themes/roneous/assets/js/lib/fluidvids5697.js?ver=5.5.3' id='fluidvids-js'></script>
<script type='text/javascript' src='../../wp-content/themes/roneous/assets/js/lib/gmap3.min5697.js?ver=5.5.3' id='gmap3-js'></script>
<script type='text/javascript' src='../../wp-content/themes/roneous/assets/js/lib/modernizr5697.js?ver=5.5.3' id='modernizr-js'></script>
<script type='text/javascript' src='../../wp-content/themes/roneous/assets/js/lib/jquery.throttle.min5697.js?ver=5.5.3' id='jsthrottle-js'></script>
<script type='text/javascript' src='../../wp-content/themes/roneous/assets/js/lib/jQuery.shuffle.min5697.js?ver=5.5.3' id='jsshuffle-js'></script>
<script type='text/javascript' id='roneous-scripts-js-extra'>
/* <![CDATA[ */
var wp_data = {"roneous_ajax_url":"https:\/\/sohom.in\/wp-admin\/admin-ajax.php","roneous_menu_height":"90","roneous_menu_open":"yes","roneous_permalink":"https:\/\/sohom.in\/2016\/08\/03\/guests-are-satisfied-with-our-services-c\/"};
/* ]]> */
</script>
<script type='text/javascript' src='../../wp-content/themes/roneous/assets/js/scripts5697.js?ver=5.5.3' id='roneous-scripts-js'></script>
<script type='text/javascript' src='../../wp-includes/js/wp-embed.min5697.js?ver=5.5.3' id='wp-embed-js'></script>
</body>

<!-- Mirrored from sohom.in/tag/developement/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 12 Apr 2021 07:07:00 GMT -->
</html>