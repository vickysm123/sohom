<section>
     <h4>Contact Us</h4>
    <div class=" container ">
        <div class="row ">
            <form action="mail.php" method="post">
         
                    <div class="col-12">
                        <input type="text" name="name" placeholder="Name*" required>
                    </div>
                    <div class="col-12">
                        <input type="text" name="phone" placeholder="Phone Number*" required pattern="[1-9]{1}[0-9]{9}">
                    </div>
                    <div class="col-12">
                        <input type="email" name="email" placeholder="Ëmail Address*" required>
                    </div>
                    <div class="col-12">
                        <textarea name="message" placeholder="Message"></textarea>
                    </div>
                     <div class="col-12">
                        <button class="submit_btn btn btn-primary" type="submit">SEND MESSAGE</button>
                    </div>
              
                <input type="hidden" id="token" name="token">
            
            </form>
        </div>
    </div>
</section>                
                <!--Remove the bottom blog card while Adding new card in top-->
                  <h4>Recent Blogs</h4>

                   <!--Blog Card -->
				    <div class="card side-bar-blog" >
				        <img class="card-img-top" src="wp-content/uploads/blogs/understanding-the-benefits-of-upvc-sliding-doors.jpg" alt="The Top 6 Benefits Of Tilt And Turn Windows Vs. Traditional Windows">
                      <div class="card-body">
                        <h5 class="card-title">Understanding The Benefits Of Upvc Sliding Doors</h5>
                        <a href="understanding-the-benefits-of-upvc-sliding-doors.php" class="btn btn-primary">Read more.</a>
                      </div>
                    </div>
                    <!--Blog Card -->

                          <!--Blog Card -->
				    <div class="card side-bar-blog" >
				        <img class="card-img-top" src="wp-content/uploads/blogs/why-should-you-install-soundproof-windows-and-doors.jpg" alt="The Top 6 Benefits Of Tilt And Turn Windows Vs. Traditional Windows">
                      <div class="card-body">
                        <h5 class="card-title">How To Choose The Right Plastic Door And Window Manufacturers</h5>
                        <a href="why-should-you-install-soundproof-windows-and-doors.php" class="btn btn-primary">Read more.</a>
                      </div>
                    </div>
                    <!--Blog Card -->
                  
                  <!--Blog Card -->
				    <div class="card side-bar-blog" >
				         <img class="card-img-top" src="wp-content/uploads/blogs/best-tips-for-choosing-french-door-and-windows.jpg" alt="Best Tips For Choosing French Door And Windows" title="Best Tips For Choosing French Door And Windows">
                      <div class="card-body">
                        <h5 class="card-title">Best Tips For Choosing French Door And Windows</h5>
                        <a href="best-tips-for-choosing-french-door-and-windows.php" class="btn btn-primary">Read more.</a>
                      </div>
                    </div>
                  
       
                  
                  
                   